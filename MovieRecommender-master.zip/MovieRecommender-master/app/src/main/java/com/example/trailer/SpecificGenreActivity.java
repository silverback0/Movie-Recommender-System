package com.example.trailer;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SpecificGenreActivity extends AppCompatActivity {

    GridView gridView;
    NewAdapter adapter;
    ArrayList<Movie> movieList;
    ArrayList<Movie> selectedMovieList;
    String selectedGenre;

    TextView selectedGenreTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.specific_genre_activity_layout);

        movieList = (ArrayList<Movie>) getIntent().getSerializableExtra("movieList");
        selectedGenre = (String) getIntent().getStringExtra("selectedGenre");

        selectedGenreTextView = (TextView) findViewById(R.id.specificGenreHeadingTextView) ;
        selectedGenreTextView.setText(selectedGenre);

        getSelectedGenreMovies();

        gridView = (GridView) findViewById(R.id.specificGenreGridView);
        adapter = new NewAdapter(this, R.layout.image_adapter_view_layout, selectedMovieList);
        gridView.setAdapter(adapter);

    }



    private void getSelectedGenreMovies()
    {
        selectedMovieList = new ArrayList<>();
        boolean found;

        for(Movie m: movieList)
        {
            found = false;

            for(String s: m.getGenreList())
            {
                if(selectedGenre.equals(s))
                {
                    found = true;
                }
            }

            if(found == true)
            {
                selectedMovieList.add(m);
            }
        }
    }
}
