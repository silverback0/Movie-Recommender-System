package com.example.trailer;

import android.content.Context;
import android.content.Intent;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class NewAdapter extends ArrayAdapter<Movie> {
    List<String>added=new ArrayList<>();
    List<String>titles;
    List<String>links;

    ArrayList<Movie> movieList;
    ArrayList<Movie> searchedMovieList;

    static Intent intent;
    Context myContext;

    int myResource;


    public NewAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Movie> objects) {
        super(context, resource, objects);
        this.myContext = context;
        this.myResource = resource;

        this.movieList = new ArrayList<>();
        this.movieList.addAll(objects);

        searchedMovieList = objects;

    }


    public int getCount() {
        return searchedMovieList.size();
    }


    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        View myview = view;
        if (myview == null) {
            LayoutInflater inflater = (LayoutInflater) myContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            myview = inflater.inflate(R.layout.image_adapter_view_layout, null);
        }

        ImageView movieImageView;
        TextView titleTextView ;
        TextView ratingTextView;

        movieImageView = myview.findViewById(R.id.movieImageView);
        titleTextView = myview.findViewById(R.id.titleTextView);
        //ratingTextView = myview.findViewById(R.id.ratingTextView);


        String imageLink = searchedMovieList.get(i).getImageLink();
        String title = searchedMovieList.get(i).getTitle();
        float rating = searchedMovieList.get(i).getRating();

        titleTextView.setText(title);
        //ratingTextView.setText(Float.toString(rating));


        Picasso.get().load(imageLink).resize(120, 180).into(movieImageView);


        final Intent intent=new Intent(myContext,TrailerPage.class);

        movieImageView.setTag(title);

        intent.putExtra("Name",(String) movieImageView.getTag());
        movieImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                myContext.startActivity(intent);
            }
        });

        return myview;
    }


    @NonNull
    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            ArrayList<Movie> results = new ArrayList<>();

            if(constraint.toString().isEmpty())
            {
                results.addAll(movieList);
            }
            else
            {
                for(Movie obj: movieList)
                {
                    if(obj.getTitle().toLowerCase().contains(constraint.toString().toLowerCase()))
                    {
                        results.add(obj);
                    }

                }
            }

            FilterResults filterResults = new FilterResults();
            filterResults.values = results;

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            searchedMovieList.clear();
            searchedMovieList.addAll((Collection<? extends Movie>) results.values);
            notifyDataSetChanged();
        }
    };

}
