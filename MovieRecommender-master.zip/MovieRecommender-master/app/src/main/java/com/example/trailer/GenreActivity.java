package com.example.trailer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class GenreActivity extends AppCompatActivity {
    ListView listView;
    ArrayAdapter<String> adapter;
    ArrayList<Movie> movieList;
    ArrayList<String> genreList;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.genre_activity_layout);

        movieList = (ArrayList<Movie>) getIntent().getSerializableExtra("movieList");

        getGenreList();

        listView = (ListView) findViewById(R.id.genreListView);
        adapter = new ArrayAdapter<String>(this, R.layout.genre_adapter_layout, R.id.genreTextView, genreList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(GenreActivity.this, SpecificGenreActivity.class);
                intent.putExtra("selectedGenre", genreList.get(position));
                intent.putExtra("movieList", movieList);
                startActivity(intent);
            }
        });
    }

    private void getGenreList()
    {
        genreList = new ArrayList<>();

        for(Movie m: movieList)
        {
            for(String s: m.getGenreList())
            {
                if(!genreList.contains(s))
                {
                    genreList.add(s);
                }
            }

        }
    }

}
