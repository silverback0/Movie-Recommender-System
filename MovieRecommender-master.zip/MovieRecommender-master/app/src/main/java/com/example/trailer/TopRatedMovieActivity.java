package com.example.trailer;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TopRatedMovieActivity extends AppCompatActivity {

    GridView gridView;
    NewAdapter adapter;
    ArrayList<Movie> movieList;
    ArrayList<Movie> topRatedMovieList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.top_rated_activity_layout);

        movieList = (ArrayList<Movie>) getIntent().getSerializableExtra("movieList");

        topRatedMovieList = new ArrayList<>();
        for(int i=0; i<5; i++)
        {
            topRatedMovieList.add(movieList.get(i));
        }

        gridView = (GridView) findViewById(R.id.movieGridView);
        adapter = new NewAdapter(this, R.layout.image_adapter_view_layout, topRatedMovieList);
        gridView.setAdapter(adapter);
    }
}


