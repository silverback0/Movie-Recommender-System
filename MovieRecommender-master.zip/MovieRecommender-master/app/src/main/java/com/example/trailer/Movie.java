package com.example.trailer;

import java.io.Serializable;
import java.util.ArrayList;

public class Movie implements Serializable, Comparable<Movie> {
    private String title;
    private String imageLink;
    private String trailerLink;
    private float rating;
    private String officialLink;
    ArrayList<String> genreList;

    public Movie(String title, String imageLink, String trailerLink, float rating, String officialLink, ArrayList<String> genreList) {
        this.title = title;
        this.imageLink = imageLink;
        this.trailerLink = trailerLink;
        this.rating = rating;
        this.officialLink = officialLink;
        this.genreList = new ArrayList<>(genreList);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public String getTrailerLink() {
        return trailerLink;
    }

    public void setTrailerLink(String trailerLink) {
        this.trailerLink = trailerLink;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getOfficialLink() {
        return officialLink;
    }

    public void setOfficialLink(String officialLink) {
        this.officialLink = officialLink;
    }

    public ArrayList<String> getGenreList() {
        return genreList;
    }

    public void setGenreList(ArrayList<String> genreList) {
        this.genreList = genreList;
    }

    @Override
    public int compareTo(Movie o) {

        if(rating < o.getRating())
        {
            return 1;
        }
        else if(rating > o.getRating())
        {
            return -1;
        }
        else
        {
            return 0;
        }

    }
}
